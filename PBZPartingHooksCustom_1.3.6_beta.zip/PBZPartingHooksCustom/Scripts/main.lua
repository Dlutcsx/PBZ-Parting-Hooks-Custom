-- PBZPartingHooksCustom: runtime settings for DualHook only.
local MOD = "PBZPartingHooksCustom"
local CLASS = "GA_Hun_DualHook_DB_C"
local CLASS_PATH = "/PBZCombatAsset/ActorData/Players/Hun/Abilities/DualHook/Default/GA_Hun_DualHook_DB." .. CLASS
local START = CLASS_PATH .. ":K2_ActivateAbility"
local IMPACT = CLASS_PATH .. ":EventReceived_05224FD845E6EB1BC1311484874AD2AD"
local FINISH = "/PBZCombatAsset/Prototypes/Abilities/Base/BP_HeavyAttack_Base.BP_HeavyAttack_Base_C:K2_OnEndAbility"
local RECOVERY_GE = "/PBZCombatAsset/Prototypes/Abilities/Talent/GE_Talent_PerfectDeflectRecoverShachi"
local ATTRIBUTE_UTILS = "/Script/SGameAttributes.AttributeUtils"
local PASSIVE = "BP_PlayerDeflectPassive_C"
local DRAIN = "CostOfTime_6_1918214C431B290CEA5A4A9CAEAA8C4A"
local TABLE = "/Game/PBZContent/DataTable/UI/DT_WeaponData.DT_WeaponData"
local ROW = "别离残钩"
local LEGACY_STEP = 0.1
local SPEC = {
    {key="ShachiCost", field="Shachi Cost", original=50, default=25, min=0, max=50},
    {key="ShachiCostMul", field="Shachi Cost Mul", original=0.33000001311302185, default=0.165, min=0, max=0.33},
    {key="ShachiCostMin", field="Shachi Cost Min", original=70, default=35, min=0, max=70},
    {key="AngerRegenCostMul", field="Anger Regen", original=70, default=1, min=1, max=5},
    {key="PowerCounterBonusPercent", default=25, min=0, max=100},
    {key="StanceDrainMultiplier", default=0.5, min=0, max=1},
    {key="WeaponMultiplierScale", default=1, min=1, max=5},
    {key="StanceStartProgress", default=100, min=0, max=100},
}

local function log(s) print("[" .. MOD .. "] " .. s .. "\n") end
local function live(o) return o and o:IsValid() end
local function near(a,b) return type(a)=="number" and type(b)=="number" and math.abs(a-b)<0.0001 end
local function finite(n) return type(n)=="number" and n==n and math.abs(n)~=math.huge end
local function folder(p) return p:gsub("[\\/][^\\/]*$", "") end
local root = folder(folder(debug.getinfo(1,"S").source:gsub("^@", "")))
local configPath = root .. "\\" .. MOD .. ".config.json"
local function read(path)
    local f = io.open(path,"rb")
    if not f then return nil end
    local s = f:read("a")
    f:close()
    return s
end
local function conflict()
    local parent = folder(root)
    for _,name in ipairs({"PBZPartingHooksHalfShachi","PBZPartingHooksNoShachi"}) do
        if read(parent .. "\\" .. name .. "\\enabled.txt") then return name end
    end
end
if conflict() then
    log("Conflicting counter mod is enabled: " .. conflict() .. ". Disable it before using this mod.")
    return
end

local config = {}
local configText
local function loadConfig()
    local text = read(configPath)
    if not text or text==configText then return false end
    if not text:match("^%s*{.*}%s*$") then log("Invalid config JSON; keeping previous values."); return false end
    local nextValues = {}
    local oldStep = tonumber(text:match('"AttackMultiplierStep"%s*:%s*([%+%-]?[%d%.eE%+%-]+)'))
    for _,s in ipairs(SPEC) do
        local token = text:match('"' .. s.key .. '"%s*:%s*([%+%-]?[%d%.eE%+%-]+)')
        local n = token and tonumber(token)
        if not token and (s.key=="StanceStartProgress" or s.key=="AngerRegenCostMul" or s.key=="PowerCounterBonusPercent") then n=s.default end
        if not token and s.key=="WeaponMultiplierScale" and finite(oldStep) and oldStep>=0 and oldStep<=1 then
            -- Preserve the old level-60 value when loading a 1.1 config.
            n=(1+59*oldStep)/(1+59*LEGACY_STEP)
        end
        if not finite(n) then
            log("Invalid " .. s.key .. "; keeping previous values.")
            return false
        end
        if n<s.min or n>s.max then
            local old=n
            n=math.max(s.min,math.min(s.max,n))
            log(s.key .. " exceeds the allowed range: " .. tostring(old) .. " -> " .. tostring(n))
        end
        nextValues[s.key]=n
    end
    config=nextValues
    configText=text
    log("Settings loaded. Counter cost, recovery, and weapon multiplier will update in memory.")
    return true
end
for _,s in ipairs(SPEC) do config[s.key]=s.default end
loadConfig()

-- Keep original values for each UE object we touch, so hot reload can restore them.
local owned = {}
local stance = {}
local tableState
local stopped = false
local tickCount = 0
local hooks = {}
local lastError = {}
local function report(area,err)
    local s=tostring(err)
    if lastError[area]~=s then log(area .. ": " .. s); lastError[area]=s end
end
local function safe(area,fn,...)
    local ok,result=pcall(fn,...)
    if not ok then report(area,result) end
    return ok,result
end

local function releaseStance(address)
    local state=stance[address]
    if not state then return end
    if live(state.passive) then
        local data=state.passive["Anger Cost Data"]
        if near(data[DRAIN],state.applied) then data[DRAIN]=state.original end
    end
    stance[address]=nil
end
local function getMaxShachi(ability,avatar)
    local probes={
        function() return ability:GetAbilitySystemComponent() end,
        function() return ability:GetAbilitySystemComponentFromActorInfo() end,
        function() return avatar:GetAbilitySystemComponent() end,
        function() return avatar.AbilitySystemComponent end,
    }
    for _,probe in ipairs(probes) do
        local ok,asc=pcall(probe)
        if ok and live(asc) then
            local hasList,attributes=pcall(function() return asc.SpawnedAttributes end)
            if hasList and attributes then
                local hasCount,count=pcall(function() return attributes:GetArrayNum() end)
                if hasCount and finite(count) and count>=0 and count<100 then
                    for i=1,count do
                        local attribute=attributes[i]
                        if live(attribute) then
                            local hasValue,value=pcall(function() return attribute.Shachi_Max.CurrentValue end)
                            if hasValue and finite(value) and value>0 then return value end
                        end
                    end
                end
            end
        end
    end
end
local function getShachiValues(ability,avatar)
    local probes={
        function() return ability:GetAbilitySystemComponent() end,
        function() return ability:GetAbilitySystemComponentFromActorInfo() end,
        function() return avatar:GetAbilitySystemComponent() end,
        function() return avatar.AbilitySystemComponent end,
    }
    for _,probe in ipairs(probes) do
        local ok,asc=pcall(probe)
        if ok and live(asc) then
            local hasList,attributes=pcall(function() return asc.SpawnedAttributes end)
            if hasList and attributes then
                local hasCount,count=pcall(function() return attributes:GetArrayNum() end)
                if hasCount and finite(count) and count>=0 and count<100 then
                    for i=1,count do
                        local attribute=attributes[i]
                        if live(attribute) then
                            local valid,current,maximum=pcall(function()
                                return attribute.Shachi.CurrentValue,attribute.Shachi_Max.CurrentValue
                            end)
                            if valid and finite(current) and finite(maximum) and maximum>0 then
                                return current,maximum
                            end
                        end
                    end
                end
            end
        end
    end
end
local function patchRegen(ability)
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    local maximum=getMaxShachi(ability,avatar)
    if not maximum then error("Cannot read the owner's current Shachi_Max; leaving Anger Regen unchanged") end
    local upfront=math.max(config.ShachiCostMin,config.ShachiCost+maximum*config.ShachiCostMul)
    local wanted=upfront*config.AngerRegenCostMul
    local current=ability["Anger Regen"]
    if not finite(current) then error("Unreadable Anger Regen") end
    local address=ability:GetAddress()
    local entry=owned[address]
    if not entry or entry.original["Anger Regen"]==nil then
        if not near(current,70) then error("Unexpected existing Anger Regen = " .. tostring(current)) end
    elseif not near(current,entry.original["Anger Regen"]) and not near(current,entry.applied["Anger Regen"]) then
        error("Another mod changed Anger Regen")
    end
    if not near(current,wanted) then
        ability["Anger Regen"]=wanted
        if not near(ability["Anger Regen"],wanted) then
            ability["Anger Regen"]=current
            error("Cannot write Anger Regen")
        end
    end
    if not entry then entry={object=ability,original={},applied={}}; owned[address]=entry end
    if entry.original["Anger Regen"]==nil then
        entry.original["Anger Regen"]=70
        log(("Anger Regen follows upfront cost: %.4g x %.4g = %.4g (Shachi_Max %.4g)")
            :format(upfront,config.AngerRegenCostMul,wanted,maximum))
    end
    entry.applied["Anger Regen"]=wanted
end
local function startCounter(context)
    if stopped then return end
    local ability=context:get()
    if not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return end
    safe("counter recovery",patchRegen,ability)
    if not ability:IsAbilityRunning() then return end
    local address=ability:GetAddress()
    if stance[address] then return end
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    for _,passive in ipairs(FindAllOf(PASSIVE) or {}) do
        if live(passive) then
            local owner=passive:GetAvatarActorFromActorInfo()
            if live(owner) and owner:GetAddress()==avatar:GetAddress() then
                for old,state in pairs(stance) do
                    if live(state.passive) and state.passive:GetAddress()==passive:GetAddress() then
                        if live(state.ability) and state.ability:IsAbilityRunning() then return end
                        releaseStance(old)
                    end
                end
                local data=passive["Anger Cost Data"]
                local original=data[DRAIN]
                if not finite(original) then error("Cannot read original stance drain") end
                local applied=original*config.StanceDrainMultiplier
                data[DRAIN]=applied
                if not near(data[DRAIN],applied) then error("Cannot write stance drain") end
                stance[address]={ability=ability,passive=passive,original=original,applied=applied}
                return
            end
        end
    end
end
local function finishCounter(context)
    local ability=context:get()
    if live(ability) then releaseStance(ability:GetAddress()) end
end
local function powerCounterBonus(context,event)
    local percent=config.PowerCounterBonusPercent
    if percent<=0 then return end
    local ability=context:get()
    if not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return end
    local payload=event:get()
    if not payload then return end
    local bullet=payload.OptionalObject
    if not live(bullet) then return end
    local data=bullet:GetData()
    if not live(data) then return end
    local skill=data.SkillType.TagName:ToString()
    if skill~="Bullet.SkillType.PowerAttack" then return end
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    local current,maximum=getShachiValues(ability,avatar)
    if not current then error("Cannot read Shachi and Shachi_Max after full-power counter") end
    local bonus=math.min(maximum-current,maximum*percent/100)
    if bonus<=0 then return end
    local cls=StaticFindObject(RECOVERY_GE .. ".GE_Talent_PerfectDeflectRecoverShachi_C")
    if not live(cls) then
        LoadAsset(RECOVERY_GE)
        cls=StaticFindObject(RECOVERY_GE .. ".GE_Talent_PerfectDeflectRecoverShachi_C")
    end
    if not live(cls) then error("Cannot load Shachi gameplay attribute definition") end
    local modifier=cls:GetCDO().Modifiers[1]
    local attribute=modifier.Attribute
    local rawName=attribute.AttributeName
    local attributeName=type(rawName)=="string" and rawName or rawName:ToString()
    if attributeName~="Shachi" then error("Recovery GE targets " .. tostring(attributeName) .. " instead of Shachi") end
    local library=StaticFindObject(ATTRIBUTE_UTILS)
    if not live(library) then error("AttributeUtils class unavailable") end
    local helper=library:GetCDO()
    if not live(helper) then error("AttributeUtils default object unavailable") end
    helper:ModifyCharacterAttributeValue(avatar,attribute,0,bonus)
    local after=getShachiValues(ability,avatar)
    log(("Full-power counter bonus: %.4g%% of Shachi_Max %.4g, requested +%.4g, Shachi %.4g -> %.4g")
        :format(percent,maximum,bonus,current,after or -1))
end
local function register(path,fn)
    if hooks[path] then return end
    if not live(StaticFindObject(path)) then return end
    RegisterHook(path,function(...)
        if not stopped then safe("hook " .. path,fn,...) end
    end)
    hooks[path]=true
end

local function inspectField(object,s)
    local entry=owned[object:GetAddress()]
    local current=object[s.field]
    if not finite(current) then error("Unreadable " .. s.field) end
    if not entry or entry.original[s.field]==nil then
        if not near(current,s.original) and not near(current,config[s.key]) then
            error("Unexpected existing " .. s.field .. " = " .. tostring(current))
        end
    elseif not near(current,entry.original[s.field]) and not near(current,entry.applied[s.field]) then
        error("Another mod changed " .. s.field)
    end
    return {object=object,property=s.field,old=current,wanted=config[s.key],stock=s.original}
end
local function patchCounter()
    local class=StaticFindObject(CLASS_PATH)
    if not live(class) then return end
    local cdo=class:GetCDO()
    if not live(cdo) then return end
    register(FINISH,finishCounter)
    register(START,startCounter)
    register(IMPACT,powerCounterBonus)
    local targets={cdo}
    if tickCount%5==0 then
        for _,o in ipairs(FindAllOf(CLASS) or {}) do
            if live(o) and o:GetAddress()~=cdo:GetAddress() and o:GetClass():GetAddress()==class:GetAddress() then
                targets[#targets+1]=o
            end
        end
    end
    local changes={}
    for _,o in ipairs(targets) do
        for i=1,3 do changes[#changes+1]=inspectField(o,SPEC[i]) end
        if o:GetAddress()~=cdo:GetAddress() then safe("counter recovery",patchRegen,o) end
    end
    local touched={}
    local ok,err=pcall(function()
        for _,c in ipairs(changes) do
            if not near(c.old,c.wanted) then
                c.object[c.property]=c.wanted
                touched[#touched+1]=c
                if not near(c.object[c.property],c.wanted) then error("Cannot write " .. c.property) end
            end
        end
    end)
    if not ok then
        for i=#touched,1,-1 do
            local c=touched[i]
            pcall(function() c.object[c.property]=c.old end)
        end
        error(err)
    end
    for _,c in ipairs(changes) do
        local address=c.object:GetAddress()
        local entry=owned[address]
        if not entry then entry={object=c.object,original={},applied={}}; owned[address]=entry end
        entry.original[c.property]=c.stock
        entry.applied[c.property]=c.wanted
    end
end

local function desired(i) return tableState.original[i]*config.WeaponMultiplierScale end
local function patchWeapon()
    local dt=StaticFindObject(TABLE)
    if not live(dt) then return end
    local row=dt:FindRow(ROW)
    if not row then return end
    local levels=row.WeaponUpLevelDatas
    local count=levels:GetArrayNum()
    if count~=59 then error("Expected 59 DualHook upgrade entries for levels 2-60; found " .. tostring(count)) end
    local weaponLevels=count
    local address=dt:GetAddress()
    if not tableState or tableState.address~=address then
        local baseline={}
        for i=1,weaponLevels do
            local value=levels[i].AttackMultipliers
            if not finite(value) or value<=0 then error("Unreadable original level " .. i) end
            baseline[i]=value
        end
        tableState={address=address,table=dt,original=baseline,applied={}}
        log(("Weapon row has %d upgrade entries (levels 2-60); scaling all (first %.4g, last %.4g).")
            :format(count,baseline[1],baseline[59]))
    end
    for i=1,weaponLevels do
        local value=levels[i].AttackMultipliers
        if not finite(value) then error("Unreadable level " .. i) end
        if not near(value,tableState.original[i]) and not near(value,tableState.applied[i]) then
            error("Unexpected level " .. i .. " multiplier " .. tostring(value))
        end
    end
    local touched={}
    local ok,err=pcall(function()
        for i=1,weaponLevels do
            local old=levels[i].AttackMultipliers
            if not near(old,desired(i)) then
                levels[i].AttackMultipliers=desired(i)
                touched[#touched+1]={index=i,old=old}
                if not near(levels[i].AttackMultipliers,desired(i)) then error("Cannot write level " .. i) end
            end
        end
    end)
    if not ok then
        for i=#touched,1,-1 do
            local c=touched[i]
            pcall(function() levels[c.index].AttackMultipliers=c.old end)
        end
        error(err)
    end
    for i=1,weaponLevels do tableState.applied[i]=desired(i) end
end

-- The blueprint weapon reader calls this just before the table is used for damage/guard break.
local function beforeWeaponRead() safe("weapon levels",patchWeapon) end
local WEAPON_READERS={
    "/PBZCombatAsset/Prototypes/Config/PBZ_MainWeaponConfig.PBZ_MainWeaponConfig_C:GetWeaponAttackMultipliers",
    "/Script/ProjectPBZ.PBZBackPackSubsystem:GetWeaponAttackMultipliers",
}
local function tick()
    if stopped then return true end
    tickCount=tickCount+1
    loadConfig()
    for address,state in pairs(stance) do
        if not live(state.ability) or not state.ability:IsAbilityRunning() then
            safe("restore stance",releaseStance,address)
        elseif live(state.passive) then
            local wanted=state.original*config.StanceDrainMultiplier
            if not near(wanted,state.applied) then
                local data=state.passive["Anger Cost Data"]
                if near(data[DRAIN],state.applied) then data[DRAIN]=wanted; state.applied=wanted end
            end
        end
    end
    if tickCount%2==0 or tickCount%5==0 then
        safe("counter fields",patchCounter)
    end
    if tickCount%2==0 then
        for _,path in ipairs(WEAPON_READERS) do safe("register weapon reader",register,path,beforeWeaponRead) end
    end
    if tickCount%5==0 then safe("weapon levels",patchWeapon) end
    return false
end

local timer=LoopInGameThreadWithDelay
if timer then
    timer(1000,tick)
else
    local queued=false
    LoopAsync(1000,function()
        if stopped then return true end
        if not queued then
            queued=true
            ExecuteInGameThread(function() queued=false; safe("update",tick) end)
        end
        return false
    end)
end
ExecuteInGameThread(function() safe("initial update",tick) end)
log("v1.3.6 beta loaded. Settings: " .. configPath)

ModRef.OnUnload=function()
    stopped=true
    ExecuteInGameThread(function()
        for address in pairs(stance) do safe("restore stance",releaseStance,address) end
        for _,entry in pairs(owned) do
            if live(entry.object) then
                for i=1,3 do
                    local s=SPEC[i]
                    if near(entry.object[s.field],entry.applied[s.field]) then
                        entry.object[s.field]=entry.original[s.field]
                    end
                end
                if entry.applied["Anger Regen"] and near(entry.object["Anger Regen"],entry.applied["Anger Regen"]) then
                    entry.object["Anger Regen"]=entry.original["Anger Regen"]
                end
            end
        end
        if tableState and live(tableState.table) then
            local row=tableState.table:FindRow(ROW)
            if row then
                local levels=row.WeaponUpLevelDatas
                if levels:GetArrayNum()==59 then
                    for i=1,59 do
                        if near(levels[i].AttackMultipliers,tableState.applied[i]) then
                            levels[i].AttackMultipliers=tableState.original[i]
                        end
                    end
                end
            end
        end
    end)
end
