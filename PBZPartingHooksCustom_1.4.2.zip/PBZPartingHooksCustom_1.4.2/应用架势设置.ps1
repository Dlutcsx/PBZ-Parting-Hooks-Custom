param(
    [string]$GameRoot = '',
    [double]$Progress = -1,
    [double]$WindowMultiplier = -1,
    [switch]$NoPause
)
$ErrorActionPreference = 'Stop'

function Wait-ForResultKey {
    if ($NoPause -or -not [Environment]::UserInteractive) { return }
    try {
        if ([Console]::IsInputRedirected) { return }
        Write-Host '按任意键关闭窗口...'
        [void][Console]::ReadKey($true)
    } catch {
        [void](Read-Host '按回车关闭窗口')
    }
}

trap {
    Write-Host ('运行失败：' + $_.Exception.Message) -ForegroundColor Red
    Wait-ForResultKey
    exit 1
}

$release = [IO.Path]::GetFullPath($PSScriptRoot)
$builder = Join-Path $release 'PakBuilder'
$retoc = Join-Path $builder 'retoc.exe'
$template = Join-Path $builder 'raw'
$pakTemplate = Join-Path $builder 'zzz_PBZPartingHooksInstant_P.pak'
$pathFile = Join-Path $release '封包目录.txt'
if ([string]::IsNullOrWhiteSpace($GameRoot)) {
    if (-not (Test-Path -LiteralPath $pathFile -PathType Leaf)) { throw "缺少封包目录文件：$pathFile" }
    $paths = @(Get-Content -LiteralPath $pathFile -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
    if ($paths.Count -ne 1) { throw '请在 封包目录.txt 中只写一行本机 ~mods 目录的完整路径。' }
    $entry = $paths[0].Trim('"')
    if (-not [IO.Path]::IsPathRooted($entry)) { throw "封包目录必须是绝对路径：$entry" }
    $pakDir = [IO.Path]::GetFullPath($entry).TrimEnd([char[]]@('\','/'))
    $paksDir = Split-Path -Parent $pakDir
    $contentDir = Split-Path -Parent $paksDir
    $projectDir = Split-Path -Parent $contentDir
    if ((Split-Path -Leaf $pakDir) -ne '~mods' -or (Split-Path -Leaf $paksDir) -ne 'Paks' -or (Split-Path -Leaf $contentDir) -ne 'Content' -or (Split-Path -Leaf $projectDir) -ne 'ProjectPBZ') {
        throw "封包目录必须指向 ProjectPBZ\Content\Paks\~mods：$pakDir"
    }
    $game = Split-Path -Parent $projectDir
} else {
    $game = [IO.Path]::GetFullPath($GameRoot)
    $pakDir = Join-Path $game 'ProjectPBZ\Content\Paks\~mods'
}
$mods = Join-Path $game 'platform\steam\ue4ss\Mods\PBZPartingHooksCustom'
$configPath = Join-Path $mods 'PBZPartingHooksCustom.config.json'
$gameToc = Join-Path $game 'ProjectPBZ\Content\Paks\ProjectPBZ-Windows.utoc'
$base = 'zzz_PBZPartingHooksInstant_P'
$abilityChunk = '7236fe5b6ab9df7100000001'
$montageChunk = '55339b56a622f9b600000001'

foreach ($p in @($retoc, $pakTemplate, $configPath, $gameToc, (Join-Path $template 'manifest.json'), (Join-Path $template "chunks\$abilityChunk"), (Join-Path $template "chunks\$montageChunk"))) {
    if (-not (Test-Path -LiteralPath $p -PathType Leaf)) { throw "缺少文件：$p" }
}
if (-not (Test-Path -LiteralPath $pakDir -PathType Container)) { throw "缺少封包目录：$pakDir" }
if (Get-Process -Name PBZ -ErrorAction SilentlyContinue) { throw '请先完全退出游戏，再应用架势设置。' }

$expectedTocHash = 'D5C3764CDAE2030361A7FA8ED1EB204787C77E767DF92BBE947763B4A2D0186B'
if ((Get-FileHash -LiteralPath $gameToc -Algorithm SHA256).Hash -ne $expectedTocHash) {
    throw '游戏资源版本与制作时不同。停止生成，避免覆盖新版本资产。'
}
$expectedAbilityHash = '2D4436DBB9E6A10495BCF3605DEC9088E032AE479F7A64021641055712BE252B'
$expectedMontageHash = '275E9DF428B048972320CD605E812B50D3A6A3ABA66D1A14C2A280E866B8CCB4'
if ((Get-FileHash -LiteralPath (Join-Path $template "chunks\$abilityChunk") -Algorithm SHA256).Hash -ne $expectedAbilityHash) { throw '技能资源校验失败。' }
if ((Get-FileHash -LiteralPath (Join-Path $template "chunks\$montageChunk") -Algorithm SHA256).Hash -ne $expectedMontageHash) { throw '动画资源校验失败。' }

if ($Progress -eq -1 -or $WindowMultiplier -eq -1) {
    $cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($Progress -eq -1) {
        $Progress = if ($null -eq $cfg.StanceStartProgress) { 20.0 } else { [double]$cfg.StanceStartProgress }
    }
    if ($WindowMultiplier -eq -1) {
        $WindowMultiplier = if ($null -eq $cfg.CounterWindowMultiplier) { 1.2 } else { [double]$cfg.CounterWindowMultiplier }
    }
}
if ([double]::IsNaN($Progress) -or [double]::IsInfinity($Progress) -or $Progress -lt 0 -or $Progress -gt 100) {
    throw 'StanceStartProgress 必须为 0–100。'
}
if ([double]::IsNaN($WindowMultiplier) -or [double]::IsInfinity($WindowMultiplier) -or $WindowMultiplier -lt 1 -or $WindowMultiplier -gt 2) {
    throw 'CounterWindowMultiplier 必须为 1–2。'
}

$stageBase = Join-Path (Split-Path -Parent $release) 'PBZPartingHooksCustom_Builds'
if (-not (Test-Path -LiteralPath $stageBase)) { New-Item -ItemType Directory -Path $stageBase | Out-Null }
$stage = Join-Path $stageBase ('build_' + [guid]::NewGuid().ToString('N'))
if (Test-Path -LiteralPath $stage) { throw '临时构建目录已存在。' }
New-Item -ItemType Directory -Path $stage | Out-Null
$raw = Join-Path $stage 'raw'
Copy-Item -LiteralPath $template -Destination $raw -Recurse

$abilityPath = Join-Path $raw "chunks\$abilityChunk"
$ability = [IO.File]::ReadAllBytes($abilityPath)
if ($ability.Length -ne 59100 -or ([BitConverter]::ToUInt32($ability, 58786) -ne [BitConverter]::ToUInt32([BitConverter]::GetBytes([single]0.5095), 0))) {
    throw '技能资源的起手数值位置与预期不符。'
}
$startSecond = [single](0.1 + ($Progress / 100.0) * (0.5095 - 0.1))
[BitConverter]::GetBytes($startSecond).CopyTo($ability, 58786)
$windowDurations = @(
    @{ Offset = 57858; Original = [single]1.3867610692978; BaseWindow = 0.337 },
    @{ Offset = 57897; Original = [single]1.584061384201; BaseWindow = 0.505 },
    @{ Offset = 57936; Original = [single]1.2719297; BaseWindow = 0.222 },
    @{ Offset = 57975; Original = [single]1.4778651; BaseWindow = 0.406 },
    @{ Offset = 58014; Original = [single]1.5837711; BaseWindow = 0.505 },
    @{ Offset = 58053; Original = [single]1.3867337; BaseWindow = 0.337 },
    @{ Offset = 58092; Original = [single]1.2716124; BaseWindow = 0.222 },
    @{ Offset = 58131; Original = [single]1.4775732; BaseWindow = 0.406 }
)
foreach ($item in $windowDurations) {
    $offset = [int]$item.Offset
    $originalBits = [BitConverter]::ToUInt32([BitConverter]::GetBytes([single]$item.Original), 0)
    if ([BitConverter]::ToUInt32($ability, $offset) -ne $originalBits) {
        throw "反制判定动作时长位置与预期不符：$offset"
    }
    # Early timeline acceleration means multiplying raw duration also multiplies the real
    # catch window too much. The measured stock game-time window is the extra duration
    # needed for one more copy of that window.
    $adjusted = [single]([double]$item.Original + ($WindowMultiplier - 1.0) * [double]$item.BaseWindow)
    [BitConverter]::GetBytes($adjusted).CopyTo($ability, $offset)
}
[IO.File]::WriteAllBytes($abilityPath, $ability)

$montagePath = Join-Path $raw "chunks\$montageChunk"
$montage = [IO.File]::ReadAllBytes($montagePath)
if ($montage.Length -ne 958 -or $montage[820] -ne 0x81 -or $montage[821] -ne 0x05 -or $montage[822] -ne 0x03) {
    throw '动画资源的改动位置与预期不符。'
}
if ($Progress -eq 0) {
    $montage[820] = 0x82
    $montage[821] = 0x03
    $montage[822] = 0x01
    [IO.File]::WriteAllBytes($montagePath, $montage)
}

$outToc = Join-Path $stage "$base.utoc"
& $retoc pack-raw $raw $outToc
if ($LASTEXITCODE -ne 0) { throw '封包生成失败。' }
& $retoc verify $outToc | Out-Null
if ($LASTEXITCODE -ne 0) { throw '新封包校验失败。' }
Write-Host '封包校验通过。'
Copy-Item -LiteralPath $pakTemplate -Destination (Join-Path $stage "$base.pak")
$names = @("$base.pak", "$base.ucas", "$base.utoc")
$existing = @($names | Where-Object { Test-Path -LiteralPath (Join-Path $pakDir $_) })
if ($existing.Count -gt 0) {
    $backupRoot = Join-Path (Split-Path -Parent $release) 'PBZPartingHooksCustom_Backups'
    if (-not (Test-Path -LiteralPath $backupRoot)) { New-Item -ItemType Directory -Path $backupRoot | Out-Null }
    $backup = Join-Path $backupRoot ('before_settings_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N'))
    if (Test-Path -LiteralPath $backup) { throw '备份目录已存在。' }
    New-Item -ItemType Directory -Path $backup | Out-Null
    foreach ($name in $existing) {
        $old = Get-Item -LiteralPath (Join-Path $pakDir $name)
        Copy-Item -LiteralPath $old.FullName -Destination (Join-Path $backup $name)
        if ((Get-FileHash -LiteralPath $old.FullName -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath (Join-Path $backup $name) -Algorithm SHA256).Hash) {
            throw "旧封包备份校验失败：$name"
        }
        Write-Host ("已备份现有封包：{0}（{1} 字节）" -f $old.FullName, $old.Length)
    }
    Write-Host "旧封包备份位置：$backup"
}
foreach ($name in $names) {
    $source = Join-Path $stage $name
    $target = Join-Path $pakDir $name
    Copy-Item -LiteralPath $source -Destination $target -Force
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash) {
        throw "安装后校验失败：$name"
    }
}
$configBackupRoot = Join-Path (Split-Path -Parent $release) 'PBZPartingHooksCustom_Backups'
if (-not (Test-Path -LiteralPath $configBackupRoot)) { New-Item -ItemType Directory -Path $configBackupRoot | Out-Null }
$configBackup = Join-Path $configBackupRoot ('config_before_settings_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '_' + [guid]::NewGuid().ToString('N') + '.json')
if (Test-Path -LiteralPath $configBackup) { throw '配置备份文件已存在。' }
Copy-Item -LiteralPath $configPath -Destination $configBackup
if ((Get-FileHash -LiteralPath $configPath -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $configBackup -Algorithm SHA256).Hash) {
    throw '配置备份校验失败。'
}
$cfg = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
if ($null -eq $cfg.PSObject.Properties['StanceStartProgress']) {
    $cfg | Add-Member -NotePropertyName 'StanceStartProgress' -NotePropertyValue $Progress
} else { $cfg.StanceStartProgress = $Progress }
if ($null -eq $cfg.PSObject.Properties['CounterWindowMultiplier']) {
    $cfg | Add-Member -NotePropertyName 'CounterWindowMultiplier' -NotePropertyValue $WindowMultiplier
} else { $cfg.CounterWindowMultiplier = $WindowMultiplier }
try {
    $cfg | ConvertTo-Json -Depth 20 | Set-Content -LiteralPath $configPath -Encoding UTF8
    $written = Get-Content -LiteralPath $configPath -Raw -Encoding UTF8 | ConvertFrom-Json
    if ([double]$written.StanceStartProgress -ne $Progress -or [double]$written.CounterWindowMultiplier -ne $WindowMultiplier) {
        throw '配置写入后读回不一致。'
    }
} catch {
    Copy-Item -LiteralPath $configBackup -Destination $configPath -Force
    throw
}
Write-Host "配置已同步；原配置备份位置：$configBackup"
$stageRoot = (Resolve-Path -LiteralPath $stageBase).Path
$stagePath = (Resolve-Path -LiteralPath $stage).Path
if (-not $stagePath.StartsWith($stageRoot + '\', [StringComparison]::OrdinalIgnoreCase) -or (Split-Path -Leaf $stagePath) -notmatch '^build_[0-9a-f]{32}$') {
    throw "临时目录不在预期范围内：$stagePath"
}
Get-ChildItem -LiteralPath $stagePath -Force | Out-Null
Remove-Item -LiteralPath $stagePath -Recurse -Force
Write-Host ("架势起手跳过前摇 {0:g}%，反制接招时间配置倍率 {1:g} 倍已写入封包和配置；请重新启动游戏。" -f $Progress, $WindowMultiplier)
Wait-ForResultKey





