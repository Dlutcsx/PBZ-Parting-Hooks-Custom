-- PBZPartingHooksCustom: runtime settings for DualHook only.
local MOD = "PBZPartingHooksCustom"
local CLASS = "GA_Hun_DualHook_DB_C"
local CLASS_PATH = "/PBZCombatAsset/ActorData/Players/Hun/Abilities/DualHook/Default/GA_Hun_DualHook_DB." .. CLASS
local START = CLASS_PATH .. ":K2_ActivateAbility"
local IMPACT = CLASS_PATH .. ":EventReceived_05224FD845E6EB1BC1311484874AD2AD"
local FINISH = "/PBZCombatAsset/Prototypes/Abilities/Base/BP_HeavyAttack_Base.BP_HeavyAttack_Base_C:K2_OnEndAbility"
local RECOVERY_GE = "/PBZCombatAsset/Prototypes/Abilities/Talent/GE_Talent_PerfectDeflectRecoverShachi"
local ATTRIBUTE_UTILS = "/Script/SGameAttributes.AttributeUtils"
local PASSIVE = "BP_PlayerDeflectPassive_C"
local DRAIN = "CostOfTime_6_1918214C431B290CEA5A4A9CAEAA8C4A"
local DEFLECT_TICK = "/PBZDeflectSystem/Actions/GAA_DeflectFrame.GAA_DeflectFrame_C:Received_ActionTick"
local DEFLECT_END = "/PBZDeflectSystem/Actions/GAA_DeflectFrame.GAA_DeflectFrame_C:Received_ActionEnd"
local MONTAGE_PATH = "/PBZCombatAsset/ActorData/Players/Hun/Montage/DualHook/Retarget/GuiChai_Yellow_Special_Defence_Start_Montage.GuiChai_Yellow_Special_Defence_Start_Montage"
local TABLE = "/Game/PBZContent/DataTable/UI/DT_WeaponData.DT_WeaponData"
local ROW = "别离残钩"
local LEGACY_STEP = 0.1
local SPEC = {
    {key="ShachiCost", field="Shachi Cost", original=50, default=25, min=0, max=50},
    {key="ShachiCostMul", field="Shachi Cost Mul", original=0.33000001311302185, default=0.165, min=0, max=0.33},
    {key="ShachiCostMin", field="Shachi Cost Min", original=70, default=35, min=0, max=70},
    {key="AngerRegenCostMul", field="Anger Regen", original=70, default=1, min=1, max=5},
    {key="PowerCounterBonusPercent", default=25, min=0, max=100},
    {key="StanceDrainMultiplier", default=0.5, min=0, max=1},
    {key="WeaponDamageScale", default=1, min=1, max=5},
    {key="WeaponBreakScale", default=1, min=1, max=5},
    {key="StanceStartProgress", default=20, min=0, max=100},
    {key="CounterWindowMultiplier", default=1.2, min=1, max=2},
}

local function log(s) print("[" .. MOD .. "] " .. s .. "\n") end
local function live(o) return o and o:IsValid() end
local function near(a,b) return type(a)=="number" and type(b)=="number" and math.abs(a-b)<0.0001 end
local function finite(n) return type(n)=="number" and n==n and math.abs(n)~=math.huge end
local function folder(p) return p:gsub("[\\/][^\\/]*$", "") end
local root = folder(folder(debug.getinfo(1,"S").source:gsub("^@", "")))
local configPath = root .. "\\" .. MOD .. ".config.json"
local function read(path)
    local f = io.open(path,"rb")
    if not f then return nil end
    local s = f:read("a")
    f:close()
    return s
end
local function conflict()
    local parent = folder(root)
    for _,name in ipairs({"PBZPartingHooksHalfShachi","PBZPartingHooksNoShachi"}) do
        if read(parent .. "\\" .. name .. "\\enabled.txt") then return name end
    end
end
if conflict() then
    log("Conflicting counter mod is enabled: " .. conflict() .. ". Disable it before using this mod.")
    return
end

local config = {}
local configText
local function loadConfig()
    local text = read(configPath)
    if not text or text==configText then return false end
    if not text:match("^%s*{.*}%s*$") then log("Invalid config JSON; keeping previous values."); return false end
    local nextValues = {}
    local oldStep = tonumber(text:match('"AttackMultiplierStep"%s*:%s*([%+%-]?[%d%.eE%+%-]+)'))
    local legacyScale = tonumber(text:match('"WeaponMultiplierScale"%s*:%s*([%+%-]?[%d%.eE%+%-]+)'))
    if not finite(legacyScale) and finite(oldStep) and oldStep>=0 and oldStep<=1 then
        legacyScale=(1+59*oldStep)/(1+59*LEGACY_STEP)
    end
    for _,s in ipairs(SPEC) do
        local token = text:match('"' .. s.key .. '"%s*:%s*([%+%-]?[%d%.eE%+%-]+)')
        local n = token and tonumber(token)
        if not token and (s.key=="StanceStartProgress" or s.key=="CounterWindowMultiplier" or s.key=="AngerRegenCostMul" or s.key=="PowerCounterBonusPercent") then n=s.default end
        if not token and (s.key=="WeaponDamageScale" or s.key=="WeaponBreakScale") then
            n=finite(legacyScale) and legacyScale or s.default
        end
        if not finite(n) then
            log("Invalid " .. s.key .. "; keeping previous values.")
            return false
        end
        if n<s.min or n>s.max then
            local old=n
            n=math.max(s.min,math.min(s.max,n))
            log(s.key .. " exceeds the allowed range: " .. tostring(old) .. " -> " .. tostring(n))
        end
        nextValues[s.key]=n
    end
    config=nextValues
    configText=text
    log("Settings loaded. Counter cost, recovery, and independent weapon multipliers will update in memory.")
    return true
end
for _,s in ipairs(SPEC) do config[s.key]=s.default end
loadConfig()

-- Keep original values for each UE object we touch, so hot reload can restore them.
local owned = {}
local stance = {}
local animationHold = {}
local weaponState
local stopped = false
local tickCount = 0
local hooks = {}
local lastError = {}
local specialCounter = {}
local function report(area,err)
    local s=tostring(err)
    if lastError[area]~=s then log(area .. ": " .. s); lastError[area]=s end
end
local function safe(area,fn,...)
    local ok,result=pcall(fn,...)
    if not ok then report(area,result) end
    return ok,result
end

-- Cache only UObject handles; never keep temporary TMap values or UI row wrappers.
local counterInstances={}
local passiveInstances={}
local passiveOwners={}
local objectObservers={}
local countersSeeded=false
local passivesSeeded=false
local PASSIVE_CLASS_PATH="/PBZDeflectSystem/Abilities/BP_PlayerDeflectPassive.BP_PlayerDeflectPassive_C"
local function rememberObject(cache,object)
    if not object then return end
    local ok,address=pcall(function() return object:GetAddress() end)
    if ok and type(address)=="number" and address~=0 then cache[address]=object end
end
local function seedObjectCaches()
    if type(NotifyOnNewObject)=="function" then
        for _,entry in ipairs({{path=CLASS_PATH,cache=counterInstances},{path=PASSIVE_CLASS_PATH,cache=passiveInstances}}) do
            local path,cache=entry.path,entry.cache
            if not objectObservers[path] then
                NotifyOnNewObject(path,function(object)
                    if stopped then return true end
                    rememberObject(cache,object)
                end)
                objectObservers[path]=true
            end
        end
    end
    if not countersSeeded and live(StaticFindObject(CLASS_PATH)) then
        for _,object in ipairs(FindAllOf(CLASS) or {}) do rememberObject(counterInstances,object) end
        countersSeeded=true
    end
    if not passivesSeeded and live(StaticFindObject(PASSIVE_CLASS_PATH)) then
        for _,object in ipairs(FindAllOf(PASSIVE) or {}) do rememberObject(passiveInstances,object) end
        passivesSeeded=true
    end
    for _,cache in ipairs({counterInstances,passiveInstances,passiveOwners}) do
        for address,object in pairs(cache) do
            if not live(object) then cache[address]=nil end
        end
    end
end
local function passiveOwner(passive)
    if not live(passive) then return nil end
    local ok,owner=pcall(function() return passive:GetAvatarActorFromActorInfo() end)
    return ok and live(owner) and owner or nil
end
local function passivesForAvatar(avatar)
    local address=avatar:GetAddress()
    local passive=passiveOwners[address]
    local owner=passiveOwner(passive)
    if owner and owner:GetAddress()==address then return {passive} end
    passiveOwners[address]=nil
    local function findCached()
        for id,candidate in pairs(passiveInstances) do
            local candidateOwner=passiveOwner(candidate)
            if candidateOwner and candidateOwner:GetAddress()==address then
                passiveOwners[address]=candidate
                return candidate
            elseif not live(candidate) then passiveInstances[id]=nil end
        end
    end
    passive=findCached()
    -- Compatibility fallback for UE4SS builds without construction notifications.
    -- This runs only on a cache miss at activation, never from the periodic tick.
    if not passive and not objectObservers[PASSIVE_CLASS_PATH] then
        for _,object in ipairs(FindAllOf(PASSIVE) or {}) do rememberObject(passiveInstances,object) end
        passive=findCached()
    end
    return passive and {passive} or {}
end

local function releaseStance(address)
    local state=stance[address]
    if not state then return end
    if live(state.passive) then
        local data=state.passive["Anger Cost Data"]
        if near(data[DRAIN],state.applied) then data[DRAIN]=state.original end
    end
    stance[address]=nil
end
local function getMaxShachi(ability,avatar)
    local probes={
        function() return ability:GetAbilitySystemComponent() end,
        function() return ability:GetAbilitySystemComponentFromActorInfo() end,
        function() return avatar:GetAbilitySystemComponent() end,
        function() return avatar.AbilitySystemComponent end,
    }
    for _,probe in ipairs(probes) do
        local ok,asc=pcall(probe)
        if ok and live(asc) then
            local hasList,attributes=pcall(function() return asc.SpawnedAttributes end)
            if hasList and attributes then
                local hasCount,count=pcall(function() return attributes:GetArrayNum() end)
                if hasCount and finite(count) and count>=0 and count<100 then
                    for i=1,count do
                        local attribute=attributes[i]
                        if live(attribute) then
                            local hasValue,value=pcall(function() return attribute.Shachi_Max.CurrentValue end)
                            if hasValue and finite(value) and value>0 then return value end
                        end
                    end
                end
            end
        end
    end
end
local function getShachiValues(ability,avatar)
    local probes={
        function() return ability:GetAbilitySystemComponent() end,
        function() return ability:GetAbilitySystemComponentFromActorInfo() end,
        function() return avatar:GetAbilitySystemComponent() end,
        function() return avatar.AbilitySystemComponent end,
    }
    for _,probe in ipairs(probes) do
        local ok,asc=pcall(probe)
        if ok and live(asc) then
            local hasList,attributes=pcall(function() return asc.SpawnedAttributes end)
            if hasList and attributes then
                local hasCount,count=pcall(function() return attributes:GetArrayNum() end)
                if hasCount and finite(count) and count>=0 and count<100 then
                    for i=1,count do
                        local attribute=attributes[i]
                        if live(attribute) then
                            local valid,current,maximum=pcall(function()
                                return attribute.Shachi.CurrentValue,attribute.Shachi_Max.CurrentValue
                            end)
                            if valid and finite(current) and finite(maximum) and maximum>0 then
                                return current,maximum
                            end
                        end
                    end
                end
            end
        end
    end
end
local function patchRegen(ability)
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    local maximum=getMaxShachi(ability,avatar)
    if not maximum then error("Cannot read the owner's current Shachi_Max; leaving Anger Regen unchanged") end
    local upfront=math.max(config.ShachiCostMin,config.ShachiCost+maximum*config.ShachiCostMul)
    local wanted=upfront*config.AngerRegenCostMul
    local current=ability["Anger Regen"]
    if not finite(current) then error("Unreadable Anger Regen") end
    local address=ability:GetAddress()
    local entry=owned[address]
    if not entry or entry.original["Anger Regen"]==nil then
        if not near(current,70) then error("Unexpected existing Anger Regen = " .. tostring(current)) end
    elseif not near(current,entry.original["Anger Regen"]) and not near(current,entry.applied["Anger Regen"]) then
        error("Another mod changed Anger Regen")
    end
    if not near(current,wanted) then
        ability["Anger Regen"]=wanted
        if not near(ability["Anger Regen"],wanted) then
            ability["Anger Regen"]=current
            error("Cannot write Anger Regen")
        end
    end
    if not entry then entry={object=ability,original={},applied={}}; owned[address]=entry end
    if entry.original["Anger Regen"]==nil then
        entry.original["Anger Regen"]=70
    end
    entry.applied["Anger Regen"]=wanted
end
local function startCounter(context)
    if stopped then return end
    local ability=context:get()
    if not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return end
    rememberObject(counterInstances,ability)
    safe("counter recovery",patchRegen,ability)
    if not ability:IsAbilityRunning() then return end
    local address=ability:GetAddress()
    if stance[address] then return end
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    for _,passive in ipairs(passivesForAvatar(avatar)) do
        if live(passive) then
            local owner=passive:GetAvatarActorFromActorInfo()
            if live(owner) and owner:GetAddress()==avatar:GetAddress() then
                for old,state in pairs(stance) do
                    if live(state.passive) and state.passive:GetAddress()==passive:GetAddress() then
                        if live(state.ability) and state.ability:IsAbilityRunning() then return end
                        releaseStance(old)
                    end
                end
                local data=passive["Anger Cost Data"]
                local original=data[DRAIN]
                if not finite(original) then error("Cannot read original stance drain") end
                local applied=original*config.StanceDrainMultiplier
                data[DRAIN]=applied
                if not near(data[DRAIN],applied) then error("Cannot write stance drain") end
                stance[address]={ability=ability,passive=passive,original=original,applied=applied}
                return
            end
        end
    end
end
local function finishCounter(context)
    local ability=context:get()
    if live(ability) then
        local address=ability:GetAddress()
        animationHold[address]=nil
        releaseStance(address)
    end
end
local function powerCounterBonus(context,event)
    if specialCounter.mark then safe("mark automatic power counter",specialCounter.mark,context,event) end
    local percent=config.PowerCounterBonusPercent
    if percent<=0 then return end
    local ability=context:get()
    if not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return end
    local payload=event:get()
    if not payload then return end
    local bullet=payload.OptionalObject
    if not live(bullet) then return end
    local data=bullet:GetData()
    if not live(data) then return end
    local skill=data.SkillType.TagName:ToString()
    if skill~="Bullet.SkillType.PowerAttack" then return end
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    local current,maximum=getShachiValues(ability,avatar)
    if not current then error("Cannot read Shachi and Shachi_Max after full-power counter") end
    local bonus=math.min(maximum-current,maximum*percent/100)
    if bonus<=0 then return end
    local cls=StaticFindObject(RECOVERY_GE .. ".GE_Talent_PerfectDeflectRecoverShachi_C")
    if not live(cls) then
        LoadAsset(RECOVERY_GE)
        cls=StaticFindObject(RECOVERY_GE .. ".GE_Talent_PerfectDeflectRecoverShachi_C")
    end
    if not live(cls) then error("Cannot load Shachi gameplay attribute definition") end
    local modifier=cls:GetCDO().Modifiers[1]
    local attribute=modifier.Attribute
    local rawName=attribute.AttributeName
    local attributeName=type(rawName)=="string" and rawName or rawName:ToString()
    if attributeName~="Shachi" then error("Recovery GE targets " .. tostring(attributeName) .. " instead of Shachi") end
    local library=StaticFindObject(ATTRIBUTE_UTILS)
    if not live(library) then error("AttributeUtils class unavailable") end
    local helper=library:GetCDO()
    if not live(helper) then error("AttributeUtils default object unavailable") end
    helper:ModifyCharacterAttributeValue(avatar,attribute,0,bonus)
end
local montageObject
local montageRateState
local montageLoadAttempted=false
local gameStatics
local function getMontage()
    if not live(montageObject) then
        montageObject=StaticFindObject(MONTAGE_PATH)
        if not live(montageObject) and not montageLoadAttempted then
            montageLoadAttempted=true
            pcall(function() LoadAsset(MONTAGE_PATH:match("^(.-)%.")) end)
            montageObject=StaticFindObject(MONTAGE_PATH)
        end
    end
    if live(montageObject) and config.CounterWindowMultiplier>1
        and (not montageRateState or not live(montageRateState.montage)
            or montageRateState.montage:GetAddress()~=montageObject:GetAddress()) then
        local original=montageObject.RateScale
        if not finite(original) or original<=0 then error("Unreadable stance montage RateScale") end
        local wanted=original*(1-0.07*(config.CounterWindowMultiplier-1))
        montageObject.RateScale=wanted
        if not near(montageObject.RateScale,wanted) then error("Cannot set stance montage RateScale") end
        montageRateState={montage=montageObject,original=original,applied=wanted}
    end
    return live(montageObject) and montageObject or nil
end
local function getAnimationInstance(avatar)
    local ok,mesh=pcall(function() return avatar:GetMesh() end)
    if not ok or not live(mesh) then mesh=avatar.Mesh end
    if not live(mesh) then return nil end
    local got,anim=pcall(function() return mesh:GetAnimInstance() end)
    return got and live(anim) and anim or nil
end
local function gameTime(avatar)
    if not live(gameStatics) then gameStatics=StaticFindObject("/Script/Engine.Default__GameplayStatics") end
    if not live(gameStatics) then return nil end
    local ok,value=pcall(function() return gameStatics:GetTimeSeconds(avatar) end)
    return ok and finite(value) and value or nil
end
local function deflectAbility(context)
    local action=context:get()
    if not live(action) then return nil,nil end
    local ok,ability=pcall(function() return action:GetAbility() end)
    if not ok or not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return nil,nil end
    return action,ability
end
-- Track only the action state needed to finish an empty counter smoothly.
local function animateCounterTick(context,elapsed,duration)
    local action,ability=deflectAbility(context)
    if not action then return end
    local address=ability:GetAddress()
    local avatar=ability:GetAvatarActorFromActorInfo()
    if not live(avatar) then return end
    local state=animationHold[address]
    if not state then
        state={ability=ability,avatar=avatar,longestDuration=0}
        animationHold[address]=state
    end
    local length=duration
    if duration then
        local ok,value=pcall(function() return duration:get() end)
        if ok then length=value end
    end
    if finite(length) and length>state.longestDuration then
        state.longestDuration=length
        state.longestAction=action:GetAddress()
    end
    local handle=action["Current Handle"]
    if finite(handle) and handle>=0 then state.hit=true end
end
local function animateCounterEnd(context)
    local action,ability=deflectAbility(context)
    if not action then return end
    local address=ability:GetAddress()
    local state=animationHold[address]
    if not state or state.longestAction~=action:GetAddress() then return end
    if not state.hit and config.CounterWindowMultiplier>1 then
        local anim=getAnimationInstance(state.avatar)
        local montage=getMontage()
        if live(anim) and live(montage) and anim:Montage_IsPlaying(montage) then
            anim:Montage_Stop(0.25,montage)
        end
    end
    animationHold[address]=nil
end
local function discardFinishedCounters()
    for address,state in pairs(animationHold) do
        if not live(state.ability) or not state.ability:IsAbilityRunning() then
            animationHold[address]=nil
        end
    end
end
local function register(path,fn)
    if hooks[path] then return end
    if not live(StaticFindObject(path)) then return end
    RegisterHook(path,function(...)
        if not stopped then safe("hook " .. path,fn,...) end
    end)
    hooks[path]=true
end

local function inspectField(object,s)
    local entry=owned[object:GetAddress()]
    local current=object[s.field]
    if not finite(current) then error("Unreadable " .. s.field) end
    if not entry or entry.original[s.field]==nil then
        if not near(current,s.original) and not near(current,config[s.key]) then
            error("Unexpected existing " .. s.field .. " = " .. tostring(current))
        end
    elseif not near(current,entry.original[s.field]) and not near(current,entry.applied[s.field]) then
        error("Another mod changed " .. s.field)
    end
    return {object=object,property=s.field,old=current,wanted=config[s.key],stock=s.original}
end
local function patchCounter()
    local class=StaticFindObject(CLASS_PATH)
    if not live(class) then return end
    local cdo=class:GetCDO()
    if not live(cdo) then return end
    register(FINISH,finishCounter)
    register(START,startCounter)
    register(IMPACT,powerCounterBonus)
    register(DEFLECT_TICK,animateCounterTick)
    register(DEFLECT_END,animateCounterEnd)
    local targets={cdo}
    for address,o in pairs(counterInstances) do
        if not live(o) then
            counterInstances[address]=nil
        elseif o:GetAddress()~=cdo:GetAddress() and o:GetClass():GetAddress()==class:GetAddress() then
            targets[#targets+1]=o
        end
    end
    local changes={}
    for _,o in ipairs(targets) do
        for i=1,3 do changes[#changes+1]=inspectField(o,SPEC[i]) end
        if o:GetAddress()~=cdo:GetAddress() then safe("counter recovery",patchRegen,o) end
    end
    local touched={}
    local ok,err=pcall(function()
        for _,c in ipairs(changes) do
            if not near(c.old,c.wanted) then
                c.object[c.property]=c.wanted
                touched[#touched+1]=c
                if not near(c.object[c.property],c.wanted) then error("Cannot write " .. c.property) end
            end
        end
    end)
    if not ok then
        for i=#touched,1,-1 do
            local c=touched[i]
            pcall(function() c.object[c.property]=c.old end)
        end
        error(err)
    end
    for _,c in ipairs(changes) do
        local address=c.object:GetAddress()
        local entry=owned[address]
        if not entry then entry={object=c.object,original={},applied={}}; owned[address]=entry end
        entry.original[c.property]=c.stock
        entry.applied[c.property]=c.wanted
    end
end

local WEAPON_CONFIG="/PBZCombatAsset/ActorData/Players/Hun/Weapon/DualHook/Weapon_Hun_DualHook.Weapon_Hun_DualHook"
local CHANNELS={
    {tag="Damage.Attack.Target.PhysicalDamage",key="WeaponDamageScale",index=1},
    {tag="Damage.Attack.Target.AngerDamage",key="WeaponBreakScale",index=2},
}
local MAP_FIELDS={"Weapon Attack Multipliers","Weapon Attack Multipliers Normalized"}
local UI_FIELDS={"UIAttributeDatas","SnapSoulUIAttributeDatas","ReincarnationUIAttributeDatas"}
local function setMapChannel(object,field,tag,wanted)
    local found=false
    object[field]:ForEach(function(key,value)
        if key:get().TagName:ToString()==tag then
            value:set(wanted)
            if not near(value:get(),wanted) then error("Cannot write "..field.." "..tag) end
            found=true
        end
    end)
    if not found then error("Missing weapon channel "..tag) end
end
local function weaponCells()
    local object=StaticFindObject(WEAPON_CONFIG)
    local dt=StaticFindObject(TABLE)
    if not live(object) or not live(dt) then return {} end
    local row=dt:FindRow(ROW)
    if not row then return {} end
    local cells={}
    for _,field in ipairs(MAP_FIELDS) do
        local found={}
        object[field]:ForEach(function(key,value)
            local tag=key:get().TagName:ToString()
            for _,channel in ipairs(CHANNELS) do
                if tag==channel.tag then
                    local current=value:get()
                    if not finite(current) or current<=0 then error("Invalid weapon channel "..tag) end
                    found[tag]=true
                    local mapField,channelTag=field,tag
                    cells[#cells+1]={id=tostring(object:GetAddress())..":"..field..":"..tag,
                        current=current,scale=config[channel.key],
                        write=function(v) setMapChannel(object,mapField,channelTag,v) end}
                end
            end
        end)
        for _,channel in ipairs(CHANNELS) do
            if not found[channel.tag] then error("Missing "..field.." "..channel.tag) end
        end
    end
    for _,field in ipairs(UI_FIELDS) do
        local count=row[field]:GetArrayNum()
        if (field=="UIAttributeDatas" and count~=2) or (count~=0 and count~=2) then
            error("Unexpected weapon UI attribute count: "..field.."="..tostring(count))
        end
        for _,channel in ipairs(CHANNELS) do
            if count>0 then
                local index,uiField=channel.index,field
                local current=row[uiField][index].DefaultValue
                if not finite(current) or current<=0 then error("Invalid weapon UI default") end
                cells[#cells+1]={id=tostring(dt:GetAddress())..":"..field..":"..index,
                    current=current,scale=config[channel.key],
                    write=function(v)
                        row[uiField][index].DefaultValue=v
                        if not near(row[uiField][index].DefaultValue,v) then error("Cannot write weapon UI value") end
                    end}
            end
        end
    end
    return cells
end
local function applyWeaponValues()
    local cells=weaponCells()
    weaponState=weaponState or {}
    for _,cell in ipairs(cells) do
        local record=weaponState[cell.id]
        if not record then
            record={original=cell.current}
            weaponState[cell.id]=record
        end
        if not near(cell.current,record.original) and not near(cell.current,record.applied) then
            error("Another mod changed weapon value "..cell.id)
        end
        cell.wanted=record.original*cell.scale
    end
    local touched={}
    local ok,err=pcall(function()
        for _,cell in ipairs(cells) do
            if not near(cell.current,cell.wanted) then
                touched[#touched+1]=cell
                cell.write(cell.wanted)
            end
        end
    end)
    if not ok then
        for i=#touched,1,-1 do pcall(touched[i].write,touched[i].current) end
        error(err)
    end
    for _,cell in ipairs(cells) do
        weaponState[cell.id].applied=cell.wanted
    end
    return #cells>0
end
local weaponSnapshot
local weaponPatchBusy=false
local function patchWeapon(force)
    if weaponPatchBusy then return false end
    local object=StaticFindObject(WEAPON_CONFIG)
    local tableObject=StaticFindObject(TABLE)
    local objectId=live(object) and object:GetAddress() or nil
    local tableId=live(tableObject) and tableObject:GetAddress() or nil
    if not force and weaponSnapshot and objectId==weaponSnapshot.objectId
        and tableId==weaponSnapshot.tableId
        and config.WeaponDamageScale==weaponSnapshot.damage
        and config.WeaponBreakScale==weaponSnapshot.breakScale then return true end
    weaponPatchBusy=true
    local ok,result=pcall(applyWeaponValues)
    weaponPatchBusy=false
    if not ok then weaponSnapshot=nil;error(result) end
    if result and objectId and tableId then
        weaponSnapshot={objectId=objectId,tableId=tableId,damage=config.WeaponDamageScale,breakScale=config.WeaponBreakScale}
    else weaponSnapshot=nil end
    return result
end
local function restoreWeapon()
    weaponSnapshot=nil
    for _,cell in ipairs(weaponCells()) do
        local record=weaponState and weaponState[cell.id]
        if record and near(cell.current,record.applied) then cell.write(record.original) end
    end
end

-- Refresh only DualHook combat channels and UI values before weapon reads.
local function beforeWeaponRead() safe("independent weapon values",patchWeapon) end
local WEAPON_READERS={
    "/PBZCombatAsset/Prototypes/Config/PBZ_MainWeaponConfig.PBZ_MainWeaponConfig_C:GetWeaponAttackMultipliers",
    "/Script/ProjectPBZ.PBZBackPackSubsystem:GetWeaponAttackMultipliers",
}
-- Execution bullets cache their attack input on initialization. Apply native
-- modifiers to the individual attack module around its synchronous damage call.
-- Never modify the shared execution assets or global damage calculators.
local EXECUTION_DAMAGE="/Script/SGameCombatSystem.BulletAttackModule:DealDamageToAvatar"
local executionHooks
local executionPending={}
local executionFrames={}
local executionSequence=0
local executionNames={
    EB_Hun_DualHook_GEx_01=true,EB_Hun_DualHook_GEx_02=true,
    EB_Hun_DualHook_GEx_03=true,EB_Hun_DualHook_GEx_04=true,
}
local EXECUTION_PHYSICAL="Damage.Attack.Target.PhysicalDamage"
local EXECUTION_BREAK="Damage.Attack.Target.AngerDamage"
local function executionTag(data,name,fn)
    local found=false
    data["Attack Data"]:ForEach(function(key,value)
        local tag=key:get()
        if tag.TagName:ToString()==name then
            found=true
            fn(tag,value:get())
        end
    end)
    return found
end
specialCounter.mark=function(context,event)
    if config.WeaponDamageScale<=1 and config.WeaponBreakScale<=1 then return end
    local ability=context:get()
    if not live(ability) or ability:GetClass():GetFName():ToString()~=CLASS then return end
    local payload=event:get()
    local incoming=payload and payload.OptionalObject
    if not live(incoming) then return end
    local data=incoming:GetData()
    if not live(data) or data.SkillType.TagName:ToString()~="Bullet.SkillType.PowerAttack" then return end
    local avatar=ability:GetAvatarActorFromActorInfo()
    local enemy=incoming:GetOwnerAvatar()
    if not live(avatar) or not live(enemy) then return end
    local now=gameTime(avatar)
    if not now then return end
    executionSequence=executionSequence+1
    executionPending[avatar:GetAddress()]={avatar=avatar,enemy=enemy,started=now,sequence=executionSequence}
end
local function restoreExecutionFrame(address)
    local frame=executionFrames[address]
    if not frame then return end
    if not live(frame.module) or not live(frame.data) then executionFrames[address]=nil;return end
    for i=#frame.applied,1,-1 do
        local item=frame.applied[i]
        if not item.restored then
            if not executionTag(frame.data,item.tag,function(tag)
                frame.module:AddModifier(tag,1,1/item.scale)
            end) then error("Execution modifier tag disappeared: "..item.tag) end
            item.restored=true
        end
    end
    executionFrames[address]=nil
end
local function beforeExecutionDamage(context,targetParam)
    if next(executionFrames)==nil and (next(executionPending)==nil
        or (config.WeaponDamageScale<=1 and config.WeaponBreakScale<=1)) then return end
    local module=context:get()
    if not live(module) then return end
    local address=module:GetAddress()
    if executionFrames[address] then
        executionFrames[address].depth=executionFrames[address].depth+1
        return
    end
    local bullet=module:GetOuter()
    if not live(bullet) or bullet:GetClass():GetFName():ToString()~="BP_PBZ_ExecutionBullet_C" then return end
    local data=module.BulletData
    if not live(data) or not executionNames[data:GetFName():ToString()] then return end
    local ability=bullet.BulletSourceAbility
    if not live(ability) or ability:GetClass():GetFName():ToString()~="GA_Hun_DualHook_GEx_C" then return end
    local avatar=bullet.BulletOwnerAvatar
    local target=targetParam:get()
    if not live(avatar) or not live(target) then return end
    local pending=executionPending[avatar:GetAddress()]
    if not pending or not live(pending.enemy) or pending.enemy:GetAddress()~=target:GetAddress() then return end
    local now=gameTime(avatar)
    if not now or now<pending.started or now-pending.started>8 then return end
    if pending.ability and pending.ability~=ability:GetAddress() then return end
    if not pending.ability and now-pending.started>2 then return end
    pending.ability=ability:GetAddress()
    local frame={module=module,data=data,depth=1,applied={},pending=pending,avatarAddress=avatar:GetAddress(),
        }
    executionFrames[address]=frame
    local ok,err=pcall(function()
        for _,spec in ipairs({
            {tag=EXECUTION_PHYSICAL,scale=config.WeaponDamageScale},
            {tag=EXECUTION_BREAK,scale=config.WeaponBreakScale},
        }) do
            if spec.scale>1 then
                executionTag(data,spec.tag,function(tag,value)
                    if not finite(value) then error("Invalid execution baseline") end
                    if value~=0 then
                        module:AddModifier(tag,1,spec.scale)
                        frame.applied[#frame.applied+1]={tag=spec.tag,scale=spec.scale}
                    end
                end)
            end
        end
    end)
    if not ok then
        safe("rollback automatic-counter modifiers",restoreExecutionFrame,address)
        error(err)
    end
end
local function afterExecutionDamage(context)
    if next(executionFrames)==nil then return end
    local module=context:get()
    if not live(module) then return end
    local address=module:GetAddress()
    local frame=executionFrames[address]
    if not frame then return end
    frame.depth=frame.depth-1
    if frame.depth>0 then return end
    local last=frame.data:GetFName():ToString()=="EB_Hun_DualHook_GEx_04"
    restoreExecutionFrame(address)
    if last and executionPending[frame.avatarAddress]==frame.pending then
        executionPending[frame.avatarAddress]=nil
    end
end
local function registerExecutionDamage()
    if config.WeaponDamageScale<=1 and config.WeaponBreakScale<=1 then
        if next(executionFrames)~=nil then return end
        if executionHooks then
            UnregisterHook(EXECUTION_DAMAGE,executionHooks[1],executionHooks[2])
            executionHooks=nil
        end
        executionPending={}
        return
    end
    if executionHooks or not live(StaticFindObject(EXECUTION_DAMAGE)) then return end
    local pre,post=RegisterHook(EXECUTION_DAMAGE,
        function(...) if not stopped then safe("automatic-counter damage",beforeExecutionDamage,...) end end,
        function(...) safe("restore automatic-counter modifiers",afterExecutionDamage,...) end)
    executionHooks={pre,post}
end
local function pruneExecutionPending()
    for address,pending in pairs(executionPending) do
        local now=live(pending.avatar) and live(pending.enemy) and gameTime(pending.avatar) or nil
        if not now or now<pending.started or now-pending.started>8 then executionPending[address]=nil end
    end
end
local function tick()
    if stopped then return true end
    tickCount=tickCount+1
    loadConfig()
    safe("cache counter objects",seedObjectCaches)
    safe("expire automatic-counter state",pruneExecutionPending)
    safe("discard finished counters",discardFinishedCounters)
    safe("register automatic-counter damage",registerExecutionDamage)
    for address,state in pairs(stance) do
        if not live(state.ability) or not state.ability:IsAbilityRunning() then
            safe("restore stance",releaseStance,address)
        elseif live(state.passive) then
            local wanted=state.original*config.StanceDrainMultiplier
            if not near(wanted,state.applied) then
                local data=state.passive["Anger Cost Data"]
                if near(data[DRAIN],state.applied) then data[DRAIN]=wanted; state.applied=wanted end
            end
        end
    end
    if tickCount%2==0 or tickCount%5==0 then
        safe("counter fields",patchCounter)
    end
    safe("montage rate",getMontage)
    if tickCount%2==0 then
        for _,path in ipairs(WEAPON_READERS) do safe("register weapon reader",register,path,beforeWeaponRead) end
    end
    if tickCount%5==0 then safe("independent weapon values",patchWeapon,true) end
    return false
end

local timer=LoopInGameThreadWithDelay
if timer then
    timer(1000,tick)
else
    local queued=false
    LoopAsync(1000,function()
        if stopped then return true end
        if not queued then
            queued=true
            ExecuteInGameThread(function() queued=false; safe("update",tick) end)
        end
        return false
    end)
end
ExecuteInGameThread(function() safe("initial update",tick) end)
log("v1.4.3 performance test loaded (diagnostic sampling removed). Settings: " .. configPath)

ModRef.OnUnload=function()
    stopped=true
    ExecuteInGameThread(function()
        for address in pairs(executionFrames) do safe("restore execution modifiers on unload",restoreExecutionFrame,address) end
        if executionHooks then
            pcall(UnregisterHook,EXECUTION_DAMAGE,executionHooks[1],executionHooks[2])
            executionHooks=nil
        end
        if montageRateState and live(montageRateState.montage)
            and near(montageRateState.montage.RateScale,montageRateState.applied) then
            montageRateState.montage.RateScale=montageRateState.original
        end
        animationHold={} 
        for address in pairs(stance) do safe("restore stance",releaseStance,address) end
        for _,entry in pairs(owned) do
            if live(entry.object) then
                for i=1,3 do
                    local s=SPEC[i]
                    if near(entry.object[s.field],entry.applied[s.field]) then
                        entry.object[s.field]=entry.original[s.field]
                    end
                end
                if entry.applied["Anger Regen"] and near(entry.object["Anger Regen"],entry.applied["Anger Regen"]) then
                    entry.object["Anger Regen"]=entry.original["Anger Regen"]
                end
            end
        end
        safe("restore independent weapon values",restoreWeapon)
    end)
end






